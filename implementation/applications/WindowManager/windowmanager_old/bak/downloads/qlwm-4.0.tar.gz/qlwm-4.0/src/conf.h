#define CONFDIR "/usr/local/qlwm/files/"
#define DVERSION "4.0\n"
